package com.example.myapplication.Etc;

public class MP_List_Item {
    private String name;

    public MP_List_Item(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
