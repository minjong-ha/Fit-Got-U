package com.example.myapplication.Etc;

public interface onFragmentListener {
    void onReceivedData(Object data);
}
