package com.example.myapplication.Etc;

public class HT3_List_Item {
    private String image;
    private int nameid;

    public HT3_List_Item(String image, int nameid) {
        this.image = image;
        this.nameid = nameid;
    }

    public String getImage() {
        return image;
    }

    public int getNameId() {
        return nameid;
    }
}
